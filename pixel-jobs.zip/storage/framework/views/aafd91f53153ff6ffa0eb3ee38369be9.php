<div>
    <div class="bg-white/10 my-10 h-px w-full"></div>
</div>
<?php /**PATH /home/ahmedelmoslmany/Laravel-demo/pixel-jobs/resources/views/components/forms/divider.blade.php ENDPATH**/ ?>