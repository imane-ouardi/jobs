<div <?php echo e($attributes->merge(["class" => "p-4 bg-white/5 rounded-b-xl border border-transparent hover:border-blue-800 transition-all duration-300 group"])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/ahmedelmoslmany/Laravel-demo/pixel-jobs/resources/views/components/panel.blade.php ENDPATH**/ ?>